package produtos_e_financeiro;

public class Vendedor extends Funcionario{
	
	public int metaDeVenda;
	public int qtdeVendas;

	public Vendedor(String nome, String cpf, String endereco, String telefone, float salarioBase, int metaDeVenda, int qtdeVendas) 
	{

		super(nome, cpf, endereco, telefone, salarioBase);
		this.metaDeVenda = metaDeVenda;
		this.qtdeVendas  = qtdeVendas;
	}

	public float bonificacao()
	{
		return 0;
	}
	public void contaVendas() {
		++qtdeVendas;
		
	}
	
}