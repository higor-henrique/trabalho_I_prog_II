package produtos_e_financeiro;

public class Estoque {

	private CadastroVendas cadastro;
	private Produto[] produto;
	private static String[] estoque;
 
    public Estoque()  
    { 
        
         estoque = new String[1500];
    }
    
    //pega  as infos do método addProduto() e guarda no vetor estoque.
    public void addnoEstoque(String[] infoProduto) 
    {
        boolean inseri = false;
        
   
        for(int i = 0; i < 1500 && !inseri; i++) 
        {
                 
                if(estoque[i] == null) 
                {                	
                	estoque[i] = infoProduto[i];
                	inseri = true;
                }                 
        }
    } 
    
    //busca um produto por nome no estoque e retorna suas infos;
    public static String buscaNoEstoque(String nome) 
    {    		
    	boolean achou = false;    	
	    	for(int i = 0; i < 15 && !achou ; i++) 
	    	{	    
	    		if(estoque[i] != null)
	    		{
	    			if(estoque[i].contains(nome)) 
	    			{
	    				achou = true;
	    				//print de teste
	    				//System.out.println(estoque[i]);
	    				return estoque[i];	    				
	    			}
	    		}
	    	}	    	    
    	return "Produto não encontrado";
    } 
    
    public static String buscaNoEstoqueComIndice(String nome, int k) 
    {    
    	boolean achou = false;    	
	    	for(int i = 0; i < 15 && !achou ; i++) 
	    	{	    			
	    			if(estoque[i].contains(nome)) 
	    			{
	    				achou = true;
	    				//print de teste
	    				//System.out.println(estoque[i]);
	    				//if(estoque ta no limite vai dar erro)
	    				return estoque[i+k];	    				
	    			} 	    				    		
	    	}	    	    
    	return "Produto não encontrado";
    }
    
    
    public void printaEstoque() 
    {
    	for(int i = 0; i < estoque.length ; i++) 
    	{
    		if(estoque[i] != null)
    		System.out.println(estoque[i]);
    	}
    	
    }
    
    public static void excluiDoEstoque(String nomeOuCod) 
    {

    	boolean retirou = false;
    	String aux = buscaNoEstoque(nomeOuCod);
    	for(int i = 0; i < estoque.length && !retirou; i++) 
    	{
    		System.out.println(nomeOuCod);
    		if(estoque[i] != null)
    		{	
    			if(aux == estoque[i]) 
    			{
    				estoque[i] = null;
    				retirou = true;
    				
    			}
    		}
    	}
    }
    
    
	public void emiteAlerta() {

	}

	/*public String[] getInfoProduto() {
		return InfoProduto;
	}*/

}