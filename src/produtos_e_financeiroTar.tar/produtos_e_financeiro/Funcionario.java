package produtos_e_financeiro;

public abstract class Funcionario extends Pessoa {


	protected float salarioBase;
	

	
	public Funcionario(String nome, String cpf, String endereco, String telefone, float salarioBase) {

		super(nome, cpf, endereco, telefone);
		this.salarioBase = salarioBase;
	}

	public abstract float bonificacao();


	
}