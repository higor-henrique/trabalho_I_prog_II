package produtos_e_financeiro;

public class CadastroVendas 
{
	
	//private Produto[] produto;
	private String dataDeVenda;
	private Vendedor vendedor;
	private float formaDePagamento;
	private int tamanhoVetor;
	private Estoque estoque;
	private boolean compraFinalizada;
	private String[][] sacola;
	private int k;
	private String[] registroVenda;

	public CadastroVendas() 
	{
		tamanhoVetor = 1;
		//produto = new Produto[tamanhoVetor];	
		compraFinalizada = false;
		k = 0;
		
		sacola = new String[20][3];
	}
	//vai precisar istanciar o estoque aqui para emitir o alerta caso esteja sem o produto.
	/*public Produto[] escolheProduto(String codigo) {
		
	}*/
	public String escolheProduto(String nomeOuCodigo) 
	{
		
		ensacola(estoque.buscaNoEstoque(nomeOuCodigo));
		return estoque.buscaNoEstoque(nomeOuCodigo);


	}
	
	public void ensacola(String infoProduto) 
	{
		boolean foi = false;
		boolean foi2 = false;
		
		String aux = "";
		String[] info = infoProduto.split("/");
		for(int i = 0; i < sacola.length && !foi; i++) 
		{

			if(sacola[i][0] != null)
			{
				if(infoProduto.contains(sacola[i][0]))
				{
					aux = estoque.buscaNoEstoqueComIndice(infoProduto, ++k);
					foi2 = true;
				}									
				
    		}
		}
		
		if(foi2 == true) 			
		 info = aux.split("/");
		
        for(int i = 0; i < sacola.length && !foi; i++) 
    	{

    		for(int j = 0; j < 3; j++)  
    		{
	    		if(sacola[i][j] == null)
	    		{	
	                if(j == 0)
	                {
	                    sacola[i][j] = info[2];  
	                }
	                else if(j == 1) 
	                {
	                    sacola[i][j] = info[1];                            
	                }
	                else if(j == 2)
	                {
	                	sacola[i][j] = "- "+info[0];
	                	foi = true;
	                }
	    		}

			}
		}
        if(foi == false)
        System.out.println("sacola cheia");
	}
	
	public void printaSacola() 
	{
		for(int i = 0; i < sacola.length; i++)
		{
			for(int j = 0; j < 3; j++) 
			{
				if(sacola[i][j] != null)
				System.out.print(sacola[i][j]+" ");
			}
			System.out.println();
		}
		
	}
	
	
	public void finalizaCompra(Vendedor vendedor, int dia, int mes, int ano, char formaPagamento, boolean aVista) 
	{	
		/*int aux = 0;
		boolean foi = false;
		for(int i = 0; i < 20 && !foi; i++) 
    	{
			
			if(registroVenda[i] == null) 
			{
				registroVenda[i] = vendedor.getNome()+ " - "+ dia + "/"+mes+"/"+ano+" - "+formaPagamento+" - "+ "a vista: "+aVista;
				aux = i;
				foi = true;
			}
			
    	}*/
		
		boolean excluiu = false;;
		String aux2;
        for(int i = 0; i < sacola.length ; i++) 
    	{        	
        	if(sacola[i] != null)
        	{	
        		aux2 = estoque.buscaNoEstoque(sacola[i][0]);
        		if(aux2 != null)
        		{	
        			estoque.excluiDoEstoque(sacola[i][0]);
        		}
        	}	   		
    	}
      
    	/*if(foi == true)     					  	    
    		System.out.println(registroVenda[aux]);
    	
		//conta uma venda para o vendedor 
		vendedor.contaVendas();*/
	}
	
	
	
	
}
