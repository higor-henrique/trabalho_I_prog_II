package produtos_e_financeiro;

public class Teste {
	public static void main(String [] args) 
	{
		CadastroVendas cd = new CadastroVendas();
		Produto pd = new Produto();
		Estoque et = new Estoque();
		Fornecedor f = new Fornecedor("Ricardo Eletro", "Av.Calogeras", "90076988000165");
		Vendedor vd = new Vendedor("Oronio", "056.456.789-56", "av.guaicurus", "981185075", 201, 4, 1);
		pd.addTipo("massa");
		pd.addTipo("doce");
		pd.addTipo("assados");
		pd.addTipo("fritos");
		
		pd.addProduto("pao","massa", 1, 2, f);
		pd.addProduto("cuecav","massa", 3, 3, f);
		pd.addProduto("bolo","doce", 2, 10, f);
		pd.addProduto("alfajor","doce", 1, 14, f);
		pd.addProduto("esfirra","assados", 1, 5, f);
		pd.addProduto("coxinha","fritos", 1, 3, f);
		pd.addProduto("biscoito","doce", 4, 4, f);
		
		
		

		cd.escolheProduto("pao");
		cd.escolheProduto("cuecav");
		cd.escolheProduto("bolo");
		cd.escolheProduto("alfajor");
		cd.escolheProduto("esfirra");
		cd.escolheProduto("coxinha");
		cd.escolheProduto("biscoito");
		cd.escolheProduto("biscoito");
		cd.escolheProduto("biscoito");
		cd.escolheProduto("biscoito");
		
		System.out.println("pintaEstoque()");
		System.out.println();
		et.printaEstoque();
		
		
		System.out.println();
		System.out.println("printaSacola()");
		cd.printaSacola();
		
		System.out.println();
		//cd.finalizaCompra(vd, 9, 06, 2001, 'd', true);
		
	}
}
