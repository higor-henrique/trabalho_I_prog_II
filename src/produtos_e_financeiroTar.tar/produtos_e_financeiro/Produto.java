package produtos_e_financeiro;

import java.util.Random;

public class Produto 
{
	
	private String nome;
	private String codigo;
	private String[] catalogoProdutos;
	private Estoque estoque;
	private String[] tipo;
	
	
	public Produto() 
	{
		catalogoProdutos = new String[1500];
		estoque = new Estoque();
		tipo = new String[50];
	}
	
	/* É preciso registrar no sistema sempre quando chega produto na padaria. Este método(addProduto), adiciona 
	  uma n quantidade de um mesmo produto e concatena suas infos para colocar na classe estoque.*/
	public void  addProduto(String nome, String tipo, int quantidade, float precoDeCusto, Fornecedor fornecedor) 
	{	
		
		addTipo(tipo);
		
		//for que é rodado n vezes, sendo n a quantidade do mesmo produto que foi solicitado o cadastro
		for(int k = 0; k < quantidade; k++)
		{	
			Random rd = new Random();
			boolean existeNome = false;
			boolean existeTipo = true;
			boolean cheio = false;
			int[] c = new int[6];
			
			for(int i = 0; i < catalogoProdutos.length && !existeNome; i++) 
			{
				
				if(catalogoProdutos[i] == null)
				{
					//gera parte do código do produto com a classe random
					for(int j = 0; j < 4; j++) 
						c[j] = rd.nextInt(9); 
							 
					codigo = retornaIdTipo(tipo)+"."+ c[0] +""+c[1]+""+c[2]+""+c[3]; 
					
					catalogoProdutos[i] = nome + "/" + tipo+ "/" + codigo +"/"+ fornecedor.getNome() +" - @"+ fornecedor.getCnpj() +"@"+"/#"+precoDeCusto+"#"+"/$"+definePrecoFinal(precoDeCusto)+"$";
					//System.out.println(nome) ;
					existeNome = true;
					
					estoque.addnoEstoque(catalogoProdutos); 
					
				}
			}
		}
	}
//----------------------------------------------------Inicio infos Tipo------------------------------------------------------------------------------------------------	
	//verifica se um tipo de produto existe 
	public boolean existeTipo(String tipo) 
	{
		boolean existe = false;
   		for(int i = 0; i < this.tipo.length && !existe; i++) 
		{	
   			if(this.tipo[i] != null) 
   			{
			if(this.tipo[i].toLowerCase().contains(tipo.toLowerCase()))
				existe = true;
   			}
		}
   		return existe;
	}
   	//quando um tipo de produto não existe ele adiciona ao vetor tipos com o nome do tipo e o id 
	public void addTipo(String tipo) 
   	{
   		
   		
		if(existeTipo(tipo) == false) {
			boolean adicionou = false;
			for(int i = 0; i < this.tipo.length && !adicionou; i++) 
			{
				
				if(this.tipo[i] == null) 
				{	
					this.tipo[i] = tipo + "/" + geraIdTipo();
					adicionou = true;
				}
			}
		}
		
   	}
	
	/*para saber que um produto é de um tipo específico é só olhar o vetor tipos e o id do produto
	 para isso é preciso que toda vez que adicionmaros um tipo, um id desse seja gerado automaticamente.
	 o método geraIdTipo() serve para isso pois ele é chamado dentro do método addTipo()*/
   	public String geraIdTipo() 
   	{
   	
   		
   		int contaTipo = 0;
   		//conta quantos tipo existem para gerar o id do adicionado
   		for(int i = 0; i < tipo.length; i++) 
   		{
   			if(tipo[i] != null)
   				contaTipo++;
   		}
   		if(contaTipo < 10) 
		{
			return "0"+contaTipo;
		}
   		
		return ""+contaTipo;
   	}
   	
   	//método que retorna o id do tipo pelo parametro nome do título
   	public String retornaIdTipo(String tipo_a_ser_analisado) {
   		
   		boolean existe = false;
   		String[] vetSplit; 
   		for(int i = 0; i < tipo.length && !existe; i++) 
   		{
   			if(tipo[i].toLowerCase().contains(tipo_a_ser_analisado.toLowerCase())) {
   				vetSplit = tipo[i].split("/");
   				return vetSplit[1];
   			}
   		}
   		return"99";
   	}
 //-----------------------------------------------------------------------------FIM infos Tipo-----------------------------------------------------	
   	
   	
   	public float definePrecoFinal(float precoDeCusto) {
   		 		
   		float precoFinal = 1 + precoDeCusto;
   		//precoFinal = precoDeCusto + impostos() + despesas() - desconto();  
   		
		return precoFinal;
	}
   	
   	
   	
   	
   	
   	
   	
   	// --------------------FALTA-----------------------------------------//
   	
   	
   	// perecivel e data de validade
   	//verificação
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
	/*public void addTipo(String tipo) 
	{	
		boolean existe = false;
		for(int i = 0; i < this.tipo.length; i++) 
		{			
			if(catalogoProdutos[i].toLowerCase().contains(tipo.toLowerCase())) 
			existe = true;
		}

		if(existe == false) 
		{ 
			for(int i = 0; i < this.tipo.length; i++) 
			{
				if(this.tipo[i] == null)
				this.tipo[i] = tipo; 
				
			}	
			//vinculatTipo(idTipo);
		}
		else
			System.out.println("tipo existente no estoque");
	}

	/*public String vinculaTipo(//int idTipo) 
	{
		//DEPOIS DEIXA O CONTADOR IGUAL A ZERO E SOMA SÓ NO FINAL COM 1
		int contador = 1;
		String vetor[];
		String vetor2[]; 
		String vetAux[] = new String[50];// vetor auxiliar
		boolean igual = false;
		//algoritmo que conta quantos tipo existem para fazer um id com a quantidade
		for(int i = 0; i < catalogoProdutos.length; i++) 
		{	
			
			
			for(int j = 0; j < catalogoProdutos.length-1; j++) 
			{	
				vetor = catalogoProdutos[j].split("/");
				vetor2 = catalogoProdutos[j+1].split("/");
				
				
				if(vetor[1] != vetor2[1]) {
					
					for(int k = 0; k < vetAux.length && !igual; k++) 
					{
						if(vetAux[k] == vetor2[1]) 
							igual = true;
					}
					if(igual == false)
						vetAux[j] = vetor[1];
						contador++;
				} 

			} 
			

		}
		if(contador > 10) 
		{
			return "0"+contador;
		}
		return ""+contador;

	}*/



   	/*public void addInfosProduto(String produto, String tipo)
    {		
    		Random gera = new Random();
    		int[] codigo = new int[6]; 
            boolean inseri = false;
            for(int i = 0; i < infoProduto.length && !inseri; i++) 
            {
                
                if(infoProduto[i] == null) 
                {	
                	for(int j = 0; j < codigo.length; j++) {
                		codigo[j] = gera.nextInt(9);
                	}
                    String cod = codigo[0]+""+codigo[1]+""+codigo[2]+""+codigo[3]+""+codigo[4]+""+codigo[5];
                    
                    infoProduto[i] = tipo + "/" + produto + "/" + cod;
                    
                    inseri = true; 
                    addnoEstoque();
                }
            }
            
            
    }*/

	///depois vou levar esse vetor catalogo para o estoque
}